#include <iostream>
#include "point.h"
#include "test_point.h"
using namespace std;
int main()
{
	test(test_square());
	test(test_lenght());

	system("pause");
	return 0;
}