#pragma once
#ifndef TEST_POINT_H
#define TEST_POINT_H
void test(bool);
bool test_square();
bool test_lenght();
#endif TEST_POINT_H
